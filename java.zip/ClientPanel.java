

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class ClientPanel extends JPanel
{
	private static final long serialVersionUID = 1L;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private String chatServer;
	private Socket client;
	private final int DELAY=33;
	private Timer timer;
	//Cliente
	int xClient = 575;
    int yClient = 40;
    //Server
    int xServer = 20;
	int yServer = 40;
    int speedY = 10;
    int xBola,yBola,rBola=50;
    int[] datos;
//    int speedXBola=10;
//    int speedYBola=5;
	public ClientPanel (String host)
	{
		addKeyListener(new ClientListener());
		timer = new Timer(DELAY, new ClientListener());
		//super("Client");
		chatServer = host;
		//Container container = getContentPane();
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(600,400));
		setFocusable(true);
        requestFocusInWindow();
    	datos = new int[3];
		timer.start();
		
		//setVisible(true);
	}
	public void paintComponent(Graphics page)
	{
        super.paintComponent(page);
        page.setColor(Color.RED);
        page.fillRect(xClient, yClient, 10, 100);
        //2 es server
        page.fillRect(xServer, yServer, 10, 100);
        page.fillOval(xBola,yBola,rBola,rBola);
	}
	private class ClientListener implements KeyListener, ActionListener {
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			int key = e.getKeyCode();
			if (key == KeyEvent.VK_UP) {
                yClient -= speedY;
            }
            if (key == KeyEvent.VK_DOWN) {
            	yClient += speedY;
            }
            repaint();
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
		}
	}
	
    public void runClient()
	{
		try
		{
			connectToServer();
			getStreams();
			processConnection();
			closeConnection();
		}
		catch(EOFException eofException)
		{
			System.out.println("Server terminated connection");
		}
		catch (IOException ioException)
		{
			ioException.printStackTrace();
		}
	}
	
	private void getStreams() throws IOException
	{
		output = new ObjectOutputStream(
				client.getOutputStream());
		output.flush();
		input = new ObjectInputStream(
				client.getInputStream());
	}
	
	private void connectToServer() throws IOException
	{
		client = new Socket(
				InetAddress.getByName(chatServer), 5000);
	}
	
	private void processConnection() throws IOException
	{			 
		int i=0;
		
		while(true)
		{
			try
			{	
				sendData(yClient);
				datos = (int[]) input.readObject();
				System.out.println("En processConnection de Client........................");
				xBola = datos[0];
				yBola = datos[1];
				yServer = datos[2];
				
				System.out.println("Clien...xBola="+datos[0]+" yBola="+datos[1]);
				System.out.println(i++);
				
			//	repaint();
			}
			catch(ClassNotFoundException classNotFoundException)
			{
				System.out.println("NorFoundEzxception..........................");
			}
		}
	}
	
	private void closeConnection() throws IOException
	{
		output.close();
		input.close();
		client.close();
	}
	private void sendData(int dat)
	{
		try
		{
			output.writeObject(dat);
			output.flush();
		}
		catch(IOException ioException)
		{
			System.out.println("En sedData.Client...ioException");
		}
	}
}
