import javax.swing.JFrame;

public class Client extends JFrame{
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ClientPanel cp = new ClientPanel("127.0.0.1");
        frame.getContentPane().add(cp);
        frame.pack();
        frame.setVisible(true);
		cp.runClient();
	}

}
