
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;



public class ServerPanel extends JPanel
{
	private static final long serialVersionUID = 1L;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private ServerSocket server;
	private Socket connection;
	private int counter = 1;
	private final int DELAY=33;
	private Timer timer;
	//Cliente
	int xClient = 575;
	int yClient = 40;
	//Servidor
	int xServer = 20;
    int yServer = 40;
    int speedY = 10;
    int xBola,yBola,rBola = 50;
    int speedXBola = 10;
    int speedYBola = 5;
    int[] datos;
    boolean conFlag=false;
	public ServerPanel()
	{
		//super("Server");
	//	Container container = getContentPane();
		addKeyListener(new ServerListener());
		timer = new Timer(DELAY, new ServerListener());
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(600,400));
        setFocusable(true);
        requestFocusInWindow();
		timer.start();	
//		setVisible(true);
		datos = new int[3];
	}
	public void paintComponent(Graphics page)
	{
        super.paintComponent(page);
        page.setColor(Color.YELLOW);
        page.fillRect(xServer, yServer, 10, 100);
        // 1 es Client
        page.fillRect(xClient, yClient, 10, 100);
        page.fillOval(xBola,yBola,rBola,rBola);
        
        if(conFlag==true)
        {
        	page.setColor(Color.WHITE);
        	page.drawString("Conectado",5,15);
        }
	}
	private class ServerListener implements KeyListener, ActionListener {

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			int key = e.getKeyCode();
			if (key == KeyEvent.VK_UP) {                
				yServer -= speedY;
            }
            if (key == KeyEvent.VK_DOWN) {
            	yServer += speedY;
            }
            repaint();
		}
		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
		}
		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
		}	
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			bolaUpdate();
			repaint();
		}
	}
	public void bolaUpdate()
	{
		if(xBola>getWidth()|| xBola<0) speedXBola = -speedXBola;
		if(yBola>getHeight()||yBola<0) speedYBola = -speedYBola;
		xBola += speedXBola;
		yBola += speedYBola;
		datos[0] = xBola;
		datos[1] = yBola;
		datos[2] = yServer;
	}
	public void runServer()
	{
		try
		{
			server = new ServerSocket(5000,100);
			while(true){
				waitForConnection();
				getStreams();
				processConnection();
				closeConnection();
				++counter;
				System.out.println("counter:" + counter);
			}
		}
		catch(EOFException eofException)
		{
			System.out.println("Cliente termina su conexión");
		}
		catch(IOException ioException)
		{
		ioException.printStackTrace();	
		}
	}
	
	private void waitForConnection() throws IOException 
	{
		connection = server.accept();
		conFlag = true;
	}
	
	private void getStreams() throws IOException
	{
		output = new ObjectOutputStream(
				connection.getOutputStream());
		output.flush();
		input = new ObjectInputStream(
				connection.getInputStream());
	}
	private void processConnection() throws IOException
	{
		int i=0;
		while(true)
		{
			try
			{
				
				yClient = (int) input.readObject();
				//System.out.println("En el server datos0=.........." + datos[0]);
				sendData(datos);
				//sendData(yServer);
				//System.out.println("datos en server0="+datos[0]);
				//System.out.println("i server:" + i++);
				repaint();
			}
			catch(ClassNotFoundException classNotFoundException)
			{
			}
		}
	}
	private void closeConnection() throws IOException
	{
		output.close();
		input.close();
		connection.close();
	}
	private void sendData(int[] dat)
	{
		try
		{
			output.writeObject(dat);
			output.flush();
		}
		catch(IOException ioException)
		{
			System.out.println("En sedData....ioException");
		}
	}
}
