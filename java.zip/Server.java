import javax.swing.JFrame;

public class Server extends JFrame{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ServerPanel sp = new ServerPanel();
        frame.getContentPane().add(sp);
        frame.pack();
        frame.setVisible(true);
		sp.runServer(); 
	}
}